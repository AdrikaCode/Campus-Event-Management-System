# Campus Event Management System.
A campus event management system that enables Administrator and Club Presidents to manage events on the campus and facilitated students and faculty members to register for events seamlessly through a clean and responsive UI.
